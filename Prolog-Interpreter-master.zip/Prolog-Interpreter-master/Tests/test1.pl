fun(X) :- red(X), car(X).
fun(X) :- blue(X), bike(X).
car("vw_beatle").
car(ford_escort).
bike(harley_davidson).
red("vw_beatle").
red(ford_escort).
blue(harley_davidson).
